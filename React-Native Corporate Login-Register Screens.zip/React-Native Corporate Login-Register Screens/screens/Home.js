import * as WebBrowser from 'expo-web-browser';
import * as React from 'react';
import { Image, Platform, StyleSheet, Text, TouchableOpacity, View, SafeAreaView, StatusBar, Dimensions, Button, TextInput, ImageBackground } from 'react-native';
import { ScrollView, TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { Feather, Ionicons } from 'react-native-vector-icons';
import { primaryColor } from '../constants/Colors';
const { width, height } = Dimensions.get('window');
//const LoginImage = require('../assets/images/8Q-zGQuK.jpg');
const LoginImage = 'http://localhost/imgh/8Q-zGQuK.jpg';
const bg = require('../assets/images/group.png')
const ImageDimens = {
  width: width / 3,
  height: width / 3
}
export default class Home extends React.Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }
  render() {
    return (
      <SafeAreaView style={{ backgroundColor: '#C2185B'}}>
        <StatusBar backgroundColor={primaryColor} />
        <View style={styles.container}>
          <Text style={styles.title}>Create an Account</Text>
          <Text style={styles.subtitle}>Enjoy some nice time with</Text>
          <Text style={styles.subtitle}>colleagues in the office</Text>
          <Image source={bg} style={styles.background} resizeMode="contain" />
          <TouchableOpacity onPress={() => this.props.navigation.navigate('Login')}>
            <Text style={styles.loginButton}>Login</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => this.props.navigation.navigate('Register')}>
            <Text style={styles.register}>Register</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
}
const styles = StyleSheet.create({
  background: {
    width: 300,
    height: 300,
    marginTop:30
  },
  container: {
    paddingTop: 50,
    paddingBottom:50,
    padding: 30,
    width: width,
    alignItems: 'center',
    justifyContent: 'flex-start',
    backgroundColor:'#e6e6e6',
    height:height

  },
  title: {
    fontSize: 30,
    fontWeight: '700',
    color: primaryColor,
    paddingBottom:20
  },
  subtitle: {
    color: '#999',
    fontSize: 16
  },
  loginButton: {
    width: width - 70,
    padding: 15,
    marginTop: 30,
    borderWidth: 0,
    borderRadius: 15,
    borderColor: primaryColor,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.32,
    shadowRadius: 5.46,
    elevation: 9,
    fontSize: 20,
    fontWeight: '700',
    backgroundColor: primaryColor,
    color: '#fff',
    textTransform:'uppercase',
    textAlign: 'center'
  },
  register: {
    fontWeight: '700',
    fontSize: 16,
    color: '#666',
    textAlign:'center',
    paddingBottom:20,
    paddingTop:30
  }
});
