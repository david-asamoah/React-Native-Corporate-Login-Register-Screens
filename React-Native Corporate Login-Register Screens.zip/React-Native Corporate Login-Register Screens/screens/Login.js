import * as WebBrowser from 'expo-web-browser';
import * as React from 'react';
import { Image, Platform, StyleSheet, Text, TouchableOpacity, View, SafeAreaView, StatusBar, Dimensions, Button, TextInput } from 'react-native';
import { ScrollView, TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { Feather, Ionicons } from 'react-native-vector-icons';
import { primaryColor } from '../constants/Colors';
const { width, height } = Dimensions.get('window');
const LoginImage = require('../assets/images/8Q-zGQuK.jpg');
const ImageDimens = {
  width: width / 3,
  height: width / 3
}

export default class Login extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      usernameFocus: false,
      passwordFocus: false
    }
    this.textInputReference = React.createRef();
  }
  componentDidMount() {
    
  }
  render() {
    const usernameInputBorder = this.state.usernameFocus ? primaryColor : "#999"
    const passwordInputBorder = this.state.passwordFocus ? primaryColor : "#999"
    return (

      <SafeAreaView style={{ backgroundColor: '#EBECF4f', flex: 1 }}>
        <StatusBar backgroundColor={primaryColor} />
        <View style={styles.header}>
          <View>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
              <Feather name="arrow-left" style={styles.backIcon} />
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.container}>
            <View>
              <Text style={styles.title}>Glad to see you!</Text>
            </View>
            {/* <View style={styles.imageWrapper}>
            <Image source={LoginImage} style={styles.image} />
          </View> */}
            <View style={styles.textInputWrapper}>
              <View>
                <TextInput
                  ref={this.textInputReference}
                  onFocus={() => this.setState({ usernameFocus: true })}
                  onBlur={() => this.setState({ usernameFocus: false })}
                  placeholder="Enter Username"
                  underlineColorAndroid="transparent"
                  style={[styles.textInput, { borderBottomColor: usernameInputBorder }]} />
              </View>
              <View>
                <TextInput
                  onFocus={() => this.setState({ passwordFocus: true })}
                  onBlur={() => this.setState({ passwordFocus: false })}
                  placeholder="Enter Password"
                  underlineColorAndroid="transparent"
                  textContentType="password"
                  style={[styles.textInput, { borderBottomColor: passwordInputBorder }]} />
              </View>
              <View>
                <TouchableOpacity onPress={() => this.props.navigation.navigate('ForgotPassword')}>
                  <Text style={{color:primaryColor, fontWeight:'700', alignSelf:'flex-end', paddingVertical:10}}>Forgot Password?</Text>
                </TouchableOpacity>
              </View>
              <View>
              <TouchableOpacity><Text style={styles.loginButton}>Login</Text></TouchableOpacity>
              </View>
              <View>
              <TouchableOpacity onPress={() => this.props.navigation.navigate('Register')}>
                  <Text style={{color:primaryColor, fontWeight:'700', alignSelf:'center', paddingVertical:20}}>Create an Account</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15
  },
  signUp: {
    fontWeight: '700',
    fontSize: 18
  },
  backIcon: {
    color: '#999',
    fontSize: 30
  },
  container: {
    padding: 30,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
    // backgroundColor: '#fff',
    //height:100
  },
  title: {
    fontWeight: '700',
    fontSize: 30,
    paddingTop: 30,
    paddingBottom: 50,
    color: primaryColor
  },
  textInputWrapper: {
    paddingVertical: 20
  },
  textInput: {
    width: '100%',
    paddingLeft: 0,
    paddingTop: 18,
    paddingBottom: 18,
    paddingRight: 0,
    marginVertical: 7,
    borderBottomWidth: 3,
    borderRadius: 0,
    //borderBottomColor: '#999',
    fontSize: 16,
    //fontWeight:'700',
    // backgroundColor: '#fff'
  },
  forgotPassword: {
    color: '#000',
    fontWeight: '700',
    fontSize: 16,
    textAlign: 'center',
    bottom: 25,
    right: 25,
  },
  imageWrapper: {
    borderRadius: 100,
    borderColor: '#fff',
    borderWidth: 3,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.32,
    shadowRadius: 5.46,
    elevation: 19,
    marginBottom: 50
  },
  image: {
    borderRadius: 100,
    width: width / 3,
    height: width / 3,
    borderColor: '#fff',
    borderWidth: 3,
  },
  loginButton: {
    width: width - 70,
    padding: 15,
    marginTop: 30,
    borderWidth: 0,
    borderRadius: 15,
    borderColor: primaryColor,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.32,
    shadowRadius: 5.46,
    elevation: 9,
    fontSize: 20,
    fontWeight: '700',
    backgroundColor: primaryColor,
    color: '#fff',
    textTransform: 'uppercase',
    textAlign: 'center'
  },
  registerButton: {
    width: width - 50,
    padding: 15,
    marginVertical: 20,
    fontSize: 20,
    fontWeight: '700',
    //backgroundColor: '#fff',
    color: '#000',
    textAlign: 'center'
  }

});
