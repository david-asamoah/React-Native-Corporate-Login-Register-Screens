


export const primaryColor = '#34366e';

