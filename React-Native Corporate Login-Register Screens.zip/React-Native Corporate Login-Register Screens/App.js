import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator, CardStyleInterpolators } from 'react-navigation-stack';
import React from 'react';
import { Animated, Easing } from 'react-native';
import { createSharedElementStackNavigator } from 'react-navigation-shared-element';
import { enableScreens } from 'react-native-screens';
import { Feather } from 'react-native-vector-icons';
import Home from './screens/Home';
import Login from './screens/Login';
import Register from './screens/Register';
import ForgotPassword from './screens/ForgotPassword';
import { YellowBox } from 'react-native';
YellowBox.ignoreWarnings(['Remote debugger']);
enableScreens();

const config = {
  animation: 'spring',
  config: {
    stiffness: 1200,
    damping: 500,
    mass: 3,
    overshootClamping: true,
    restDisplacementThreshold: 0.01,
    restSpeedThreshold: 0.01,
  },
};

Login.navigationOptions = {
  cardStyleInterpolator: forFade,
  transitionSpec: {
    open: config,
    close: config,
  },
};

Register.navigationOptions = {
  cardStyleInterpolator: forFade,
  transitionSpec: {
    open: config,
    close: config,
  },
};

ForgotPassword.navigationOptions = {
  cardStyleInterpolator: forFade,
  transitionSpec: {
    open: config,
    close: config,
  },
};


const forFade = ({ current, next }) => {
  const opacity = Animated.add(
    current.progress,
    next ? next.progress : 0
  ).interpolate({
    inputRange: [0, 1, 2],
    outputRange: [0, 1, 0],
  });

  return {
    leftButtonStyle: { opacity },
    rightButtonStyle: { opacity },
    titleStyle: { opacity },
    backgroundStyle: { opacity },
  }
};
const StackNavigator = createStackNavigator(
  {
    Home: Home,
    Login: Login,
    Register: Register,
    ForgotPassword: ForgotPassword
  },
  {
    initialRouteName: 'Home',
    headerMode: 'none',
    mode: "modal",
    defaultNavigationOptions: {
      cardStyleInterpolator: ({ current: { progress } }) => {
        const opacity = progress.interpolate({
          inputRange: [0, 0.8, 1, 1.2, 2],
          outputRange: [0, 0.5, 1, 0.33, 0],
          extrapolate: "clamp"
        });
        return { cardStyle: { opacity } };
      },
      gestureEnabled: true,
      cardStyle: {
        // backgroundColor: "#fff"
      }
    }
  },

);

const Menu = createAppContainer(StackNavigator);

class App extends React.Component {
  render() {
    return (
      //  <SharedElementRenderer>
      <Menu />
      //  </SharedElementRenderer>
    );
  }
}
export default App
